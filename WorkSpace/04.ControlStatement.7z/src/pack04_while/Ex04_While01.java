package pack04_while;

public class Ex04_While01 {
	public static void main(String[] args) {
		//아까 1번문제 홀수만 출력하는거
		//아직 잘 이해가 안됩니당
		//오리 증감식 위치에 따라 값이 다르게 출력되는 이유
		// 1~50 % 2 나머지 1 홀수
//		int i = 1;
//		while(i<=50) {
//			System.out.println(i);
//			if(i%2 == 1) {
//				
//			}
//			i+=2;//
//		}
		int i = 0;
		while(i<=10) {
			i++;
			System.out.println(i);
		}
	}
}
